public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean iD = new Pythagorean();
        double result = iD.calculateHypotenuse(25, 13);
        System.out.println(result);
    }
}