public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz iD = new FizzBuzz();
        String result = iD.fizzBuzz(2);
        System.out.println(result);
    }
}